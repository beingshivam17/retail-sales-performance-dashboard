# Report Build Guide

Use a 16:9 canvas (1280 × 720), white/light-grey background, dark navy text, one restrained accent colour, consistent spacing, and no more than 5–6 visuals per page. Avoid decorative icons and excessive gradients. Add a small footer with report name and selected date range.

## Page 1 — Executive Overview
**Audience question:** How are sales and profit performing overall?
- KPI cards: Total Sales, Total Profit, Profit Margin %, Total Orders, Average Order Value
- Line chart: Total Sales by MonthYear; use DimDate month-year on the axis and sort by a month index/date
- Bar chart: Total Sales by Region
- Bar chart: Total Profit by Category
- Small table: Top 5 products by sales with Sales, Profit and Margin
- Slicers: Date, Region, Category, Segment
- Add dynamic title only if comfortable; keep labels clear and avoid clutter.

## Page 2 — Sales Trends
**Audience question:** When are sales rising or falling?
- Monthly sales and sales LY line chart
- Sales by quarter clustered column chart
- Sales by OrderChannel stacked column chart
- Matrix by Region and Month with Total Sales and YoY %
- Slicers: Year, Quarter, Region, Channel

## Page 3 — Product & Category
**Audience question:** Which products generate revenue and profit?
- Bar chart: Top 10 products by sales (use Sales Rank by Product filter)
- Scatter: Sales vs Profit by ProductName; size by Units Sold if useful
- Matrix: Category > Subcategory > Product with Sales, Profit, Margin, Units Sold
- Decomposition tree: Total Profit explained by Category, Region, Segment and Product
- Slicers: Category, Subcategory, Product

## Page 4 — Customer Analysis
**Audience question:** Which customer groups and locations matter most?
- Sales by Segment donut or bar (prefer bar if labels are crowded)
- Sales by AcquisitionChannel
- Top 10 customers by sales
- Map only if city/state geocoding is reliable; otherwise use a region/city bar chart
- Cards: Customer Count, Sales per Customer, Average Order Value
- Slicers: Segment, Region, State, AcquisitionChannel

## Page 5 — Regional & Sales Team
**Audience question:** Which territories and salespeople need attention?
- Sales by Region and City
- Sales and Profit by Salesperson
- Matrix: Region > Salesperson with Sales, Profit, Margin and Orders
- Conditional formatting on margin and sales
- Slicers: Region, Salesperson, Date

## Page 6 — Orders & Returns
**Audience question:** What share of orders are returned, and where?
- Cards: Total Orders, Return Orders, Return Rate %, Discount Value
- Bar chart: Returns by Product and Category
- Bar chart: Return Rate by Region
- Table: Returned orders with date, city, product, customer and net sales
- Slicers: OrderStatus, PaymentMethod, OrderChannel, Date

## Interaction and polish
- Sync Date, Region and Category slicers across pages where appropriate.
- Create a drill-through page for Product Detail (product, sales trend, profit, units, return rate).
- Add a report-page tooltip for ProductName with Sales, Profit, Margin and Units Sold.
- Add buttons for page navigation and a “Reset filters” bookmark if practical.
- Keep titles action-oriented: “Sales softened in Q3” only if the data actually supports that statement; otherwise use neutral labels.
- Use consistent units, currency formatting, readable labels and alt text.
- Validate all measures and totals before publishing.
