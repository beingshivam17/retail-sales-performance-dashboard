# Retail Sales Performance | Power BI Portfolio Project

## Business brief
A fictional multi-region retailer selling office furniture, technology and office supplies wants a clear view of sales, profitability, customer segments, product mix and returns. The report is designed for a sales manager who needs to understand what is performing well and where follow-up is needed.

## Dataset
- 8,500 transaction rows across 2024–2025
- 1,250 customers, 20 products and 16 salespeople
- Four regions and multiple cities
- Synthetic data created for portfolio practice; it is not real company performance
- Currency: INR (₹)
- The raw transaction file includes a small number of trailing spaces in text columns for a realistic Power Query cleaning exercise.

## Files
- `Data/Retail_Transactions_Raw.csv` — main fact table source
- `Data/Dim_Product.csv` — product lookup
- `Data/Dim_Customer.csv` — customer and geography attributes
- `Data/Dim_Salesperson.csv` — salesperson lookup
- `Data/Dim_Date.csv` — calendar table
- `Data/Retail_Sales_Source_Workbook.xlsx` — all source tables in one workbook
- `PowerBI_Guides/DAX_Measures.dax` — starter measures
- `PowerBI_Guides/Power_Query_M_Starter.pq` — sample transformation steps
- `PowerBI_Guides/Report_Build_Guide.md` — page-by-page report plan
- `Documentation/Resume_and_GitHub.md` — portfolio and resume wording

## Recommended model
Use a star schema. Rename the raw fact query to `FactSales`; rename dimensions to `DimProduct`, `DimCustomer`, `DimSalesperson`, and `DimDate`.

Create one-to-many, single-direction relationships:
- `DimProduct[ProductKey]` → `FactSales[ProductKey]`
- `DimCustomer[CustomerKey]` → `FactSales[CustomerKey]`
- `DimSalesperson[SalespersonKey]` → `FactSales[SalespersonKey]`
- `DimDate[Date]` → `FactSales[OrderDate]`

Set data types before relationships. Ensure `DimDate[Date]` is Date type, mark `DimDate` as the date table, and sort `DimDate[MonthName]` by `DimDate[MonthNumber]`. Use single-direction filtering from dimensions to fact.

## Build checklist
1. Import CSV files from the `Data` folder.
2. In Power Query, trim/clean text, set correct data types, remove duplicates using `TransactionKey`, and verify there are no blank keys.
3. Build the star schema and validate relationship cardinality.
4. Add the DAX measures from `DAX_Measures.dax`; format sales/profit/cost as ₹ currency, percentages as percentages, and order/unit counts as whole numbers.
5. Build report pages using the guide.
6. Add synced slicers, page navigation, drill-through, report tooltips, and a reset-filters button if time allows.
7. Validate totals against a simple Excel pivot table and test each slicer.
8. Save the final report as `Retail_Sales_Performance.pbix`.
9. Take 2–3 screenshots for the GitHub README and update the project description with what you personally validated.

## Important integrity note
This package includes source data, model guidance and starter formulas, not a precompiled `.pbix` file. Open the included data in Power BI Desktop to build and save the interactive report. Do not claim to have built or validated report features you have not actually tested.
