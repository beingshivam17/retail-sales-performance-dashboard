# Resume & GitHub wording

## Resume project entry
**Retail Sales Performance Dashboard | Power BI, DAX, Power Query, Excel**
- Developed a multi-page Power BI sales analysis report using 8,500 transaction records spanning 2024–2025 across product, customer, regional and sales-team dimensions.
- Designed a star-schema data model and prepared source tables in Power Query by standardising data types, cleaning text fields and validating transaction keys.
- Created DAX measures for sales, profit, margin, average order value, discounts, returns, year-over-year performance and year-to-date trends.
- Planned executive, trend, product, customer, regional and returns report pages with slicers, drill-through and tooltip interactions.

**Use only after you have actually built and tested the report.** Remove or adjust any bullet that does not reflect your final PBIX.

## GitHub repository
Suggested name: `retail-sales-performance-powerbi`

Suggested description:
`Power BI portfolio project analysing retail sales, profit, product mix, customer segments, regional performance and returns using a star-schema model, Power Query and DAX.`

Suggested repository structure:
- `Data/` — CSV source tables and Excel source workbook
- `PowerBI_Guides/` — DAX and Power Query starter scripts, report build guide
- `Screenshots/` — add your own screenshots from the completed Power BI report
- `README.md` — business problem, data, model, KPIs, report pages, findings and limitations

## README findings section
After building the report, write 3–5 findings based on your own visuals. For each finding include:
1. What changed or stands out
2. The measure/visual that supports it
3. Why it matters to a sales manager
4. A practical next step

Do not invent business findings before checking the report. Dataset values are synthetic and should be described as portfolio/demo data.
