# Data Dictionary

## FactSales (source: Retail_Transactions_Raw.csv)
- TransactionKey: unique transaction-line identifier (text)
- OrderID: order identifier; can repeat across lines in a real line-item dataset, distinct count for orders
- OrderDate: transaction date
- OrderTime: transaction time
- CustomerKey / ProductKey / SalespersonKey: dimension keys
- Region / City: transaction geography snapshots
- Quantity: units sold
- UnitPrice: selling price per unit before discount
- DiscountPct: discount rate
- DiscountAmount: total discount amount on the line
- GrossSales: Quantity × UnitPrice
- NetSales: GrossSales − DiscountAmount
- TotalCost: estimated cost of goods sold
- Profit: NetSales − TotalCost
- OrderStatus: Completed or Returned; for this sample a returned line remains in the sales fact and Return Amount is not separately netted out. Interpret return-rate visuals as status incidence, not accounting-adjusted net sales.
- PaymentMethod: payment method
- OrderChannel: Online, In-store or Phone

## Dim_Product
ProductKey, ProductName, Category, Subcategory, ListPrice, UnitCost

## Dim_Customer
CustomerKey, CustomerName, Segment, Region, City, State, AcquisitionChannel

## Dim_Salesperson
SalespersonKey, SalespersonName, Region, SalesChannel

## Dim_Date
Date, Year, Quarter, MonthNumber, MonthName, MonthYear, Weekday, IsWeekend
